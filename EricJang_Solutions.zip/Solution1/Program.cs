﻿using System;
using System.Collections.Generic;

namespace Solution1
{
    class Program
    {
        static void Main(string[] args)
        {
            int result;

            if (isDigitsOnly(args[0]))
            { // check the argument is digit only or not
                result = Convert.ToInt32(args[0]);
            }
            else
            {
                //parsing argument to strings 
                string[] syntax = args[0].Split(" ");

                int leftOperand = 0;
                int rightOperand = 0;
                string poppedOperator = "";

                //Instantiation a stack to store each syntax
                //In this version, I used only 1 stack.
                Stack<string> formStack = new Stack<string>();

                //Read the syntax in orders and push to stacks and calculate except the last one
                for (int i = 0; i < syntax.Length; i++)
                {
                    if (syntax[i].Equals("(add"))
                    {
                        formStack.Push("add");
                    }
                    else if (syntax[i].Equals("(multiply"))
                    {
                        formStack.Push("multiply");
                    }
                    else
                    {
                        if (!syntax[i].EndsWith(")"))
                        {
                            formStack.Push(syntax[i]);
                        }
                        else // if the element ends with ")", it means that the function should be executed.
                        {

                            rightOperand = Int32.Parse(syntax[i].Replace(")", ""));
                            leftOperand = Convert.ToInt32(formStack.Pop());
                            poppedOperator = formStack.Pop();
                            result = executeCalculation(poppedOperator, leftOperand, rightOperand);
                            formStack.Push(result.ToString());

                        }
                    }
                }


                //Calculate final result  
                rightOperand = Convert.ToInt32(formStack.Pop());
                leftOperand = Convert.ToInt32(formStack.Pop());
                poppedOperator = formStack.Pop();
                result = executeCalculation(poppedOperator, leftOperand, rightOperand);
            }


            Console.WriteLine(result);

            Console.ReadLine();
        }

        //Calculation Method
        static int executeCalculation(string operation, int leftOperand, int rightOperand)
        {
            if (operation.Equals("add"))
            {
                return add(leftOperand, rightOperand);
            }
            else
            {
                return multiply(leftOperand, rightOperand);
            }


        }
        //add & multiply method
        static int add(int firstNum, int secondNum)
        {
            return firstNum + secondNum;
        }

        static int multiply(int firstNum, int secondNum)
        {
            return firstNum * secondNum;
        }

        //check only digits exist
        static bool isDigitsOnly(string str)
        {
            foreach (char c in str)
            {
                if (c < '0' || c > '9')
                {
                    return false;
                }
            }
            return true;
        }

    }
}

