﻿using System;
using System.Collections.Generic;

/**
 * Within this solution, I will use 2 stacks for storing operators and numbers
 * 
 * */

namespace Solution2
{
    class Program
    {
        static void Main(string[] args)
        {

            int result = solution2(args);

            Console.WriteLine(result);
            Console.ReadLine();
        }
        //Trying to use 2 stacks separated by the data type
        static int solution2(string[] args)
        {
            int result = 0;

            //Convert parameter to a string array delim
            if (isDigitsOnly(args[0]))
            {
                result = Convert.ToInt32(args[0]);
            }
            else // dealing with parameter which has s-expression
            {
                string[] param = args[0].Split(" "); // converts to string array with parameter
                // creates 2 stack storing with different data type
                Stack<string> operators = new Stack<string>();
                Stack<int> numbers = new Stack<int>();

                //traverse parameter
                for (int i = 0; i < param.Length; i++)
                {
                    if (param[i].Equals("(add"))
                    {
                        operators.Push("add");
                    }
                    else if (param[i].Equals("(multiply"))
                    {
                        operators.Push("multiply");
                    }
                    else if (isDigitsOnly(param[i]))
                    {
                        numbers.Push(Convert.ToInt32(param[i])); //convert to int and store to the stack
                    }
                    else if (param[i].EndsWith(")"))  // calculate function 
                    {

                        int numberOfBrakets = param[i].Split(")").Length - 1;
                        for(int j = 0; j < numberOfBrakets; j++)
                        {
                            int second;
                            int first;
                            if (j == 0)
                            {
                                second = Convert.ToInt32(param[i].Replace(")", ""));
                            }
                            else
                            {
                                second = numbers.Pop();
                            }

                            string poppedOperator = operators.Pop();

                            if (poppedOperator.Equals("add"))
                            {
                                first = numbers.Pop();
                                second = add(first, second);
                                numbers.Push(second);
                            }
                            else if (poppedOperator.Equals("multiply"))
                            {
                                first = numbers.Pop();
                                second = multiply(first, second);
                                numbers.Push(second);
                            }

                        }
                    }
                }
                result = numbers.Pop();
            }
            return result;
        }
        //add function 
        static int add(int first, int second)
        {
            return first + second;
        }

        //multiply function
        static int multiply(int first, int second)
        {
            return first * second;
        }

        //check the parameter is digits only or not
        static bool isDigitsOnly(string param)
        {
            foreach(char c in param)
            {
                if(c < '0'  || c > '9')
                {
                    return false;
                }
            }
            return true;
        }

    }
}
